package com.example.edgar.democraticmessage.Services;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;

public class UserData extends Service {
    private final IBinder binder = new DataBinder();

    private int userBudget = 0;
    private String userBudgetType = "";
    private boolean noBudget = false;
    private int timeUsed = 0;
    private String roomKey = "";
    private String roomType = "";

    public UserData() {
    }


    public class DataBinder extends Binder implements IInterface{
        @Override
        public IBinder asBinder() {
            return this;
        }
        //Setter for conference type
        public void setRoomType(String type){roomType = type;}
        //Getter for conference type
        public String getRoomType(){return roomType;}
        //Setter for the talk budget value
        public void setBudget(int budget) {userBudget = budget;}
        //Getter for the talk budget value
        public int getBudget() {return userBudget;}
        //Setter for talk budget type
        public void setBudgetType(String type) {userBudgetType = type;}
        //Getter for talk budget type
        public String getBudgetType() {return userBudgetType;}
        //Setter for the no budget flag
        public void setEmpty(boolean empty){noBudget = empty;}
        //Getter for the no budget flag
        public boolean getEmpty() {return noBudget;}
        //Getter for the time used
        public int getTimeUsed() {return timeUsed;}
        //Adder for the time used
        public void addTimeUsed(int used){timeUsed += used;}
        //Setter for the time used
        public void setTimeUsed(int used){timeUsed = used;}
        //Setter for the room id
        public void setRoomKey(String key){roomKey = key;}
        //Getter for the room id
        public String getRoomKey() {return roomKey;}

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return Service.START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {return binder;}
}
